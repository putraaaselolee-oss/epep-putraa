FF FULL SKIN SIMULATOR

Isi ZIP:
- index.html: aplikasi simulator koleksi skin.

Cara melihat:
1. Ekstrak ZIP.
2. Buka folder hasil ekstrak.
3. Buka index.html menggunakan browser Android.

Catatan:
Ini hanya simulator tampilan/preview. Tidak membuka item, mengubah inventaris,
atau menambahkan diamond pada akun Free Fire asli.
